/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.review;

import com.create.CreateidDao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author abhishek
 */
public class ReviewDao {

    String url = "jdbc:mysql://localhost:3306/khabri";
    String username = "root";
    String password = "";
    String sql = "INSERT INTO movie VALUES (?,?,?)";

    public void reviewing(String mname, String mreview, String uname) {

        try {
            Class.forName("com.mysql.jdbc.Driver");
            try (Connection con = DriverManager.getConnection(url, username, password)) {
                PreparedStatement st = con.prepareStatement(sql);
                st.setString(1, mname);
                st.setString(2, mreview);
                st.setString(3, uname);
                st.executeUpdate();
                con.close();
            }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CreateidDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
