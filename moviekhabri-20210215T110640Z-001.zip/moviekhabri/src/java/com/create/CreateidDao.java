package com.create;

import com.login.LoginDao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author abhishek
 */
public class CreateidDao {

    String url = "jdbc:mysql://localhost:3306/khabri";
    String username = "root";
    String password = "";
    String sql = "INSERT INTO login VALUES (?,?)";

    public void insert(String uname, String pass) {

        try {
            Class.forName("com.mysql.jdbc.Driver");
            try (Connection con = DriverManager.getConnection(url, username, password)) {
                PreparedStatement st = con.prepareStatement(sql);
                st.setString(1, uname);
                st.setString(2, pass);
                st.executeUpdate();
                con.close();
            }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CreateidDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
