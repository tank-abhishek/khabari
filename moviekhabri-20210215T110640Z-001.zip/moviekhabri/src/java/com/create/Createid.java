package com.create;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Createid extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String uname = request.getParameter("uname");
        String pass = request.getParameter("pass");

        // HttpSession session = request.getSession();
        CreateidDao cdao = new CreateidDao();
        if (uname != null & pass != null) {
            cdao.insert(uname, pass);
            response.sendRedirect("login.jsp");
        } else {
            response.sendRedirect("createid.jsp");
        } /*
        HttpSession session = request.getSession();
        session.removeAttribute("username");
        session.invalidate();
        response.sendRedirect("login.jsp");
         */
    }
}
