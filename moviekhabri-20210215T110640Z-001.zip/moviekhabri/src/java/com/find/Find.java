package com.find;

import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.console;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author abhishek
 */
public class Find extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String mname = request.getParameter("mname");

        if (mname != null) {
            String url = "jdbc:mysql://localhost:3306/khabri";
            String username = "root";
            String password = "";
            String sql = "SELECT * FROM movie WHERE mname = ?";

            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection(url, username, password);
                PreparedStatement st = con.prepareStatement(sql);
                st.setString(1, mname);
                ResultSet rs = st.executeQuery();
                String getmreview = "";
                String getuname = "";
                while (rs.next()) {
                    getuname = rs.getString("uname");
                    getmreview = rs.getString("review");
                }

                HttpSession session = request.getSession();
                session.setAttribute("getmreview", getmreview);
                session.setAttribute("getuname", getuname);
                session.setAttribute("getmname", mname);
                response.sendRedirect("find.jsp");
                con.close();

            } catch (Exception ex) {
                PrintWriter out = response.getWriter();
                out.print("hello" + ex);
                Logger.getLogger(Find.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            response.sendRedirect("login.jsp");
        }

    }
}
